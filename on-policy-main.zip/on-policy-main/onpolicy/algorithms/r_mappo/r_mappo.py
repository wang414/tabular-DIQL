import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from onpolicy.utils.util import get_gard_norm, huber_loss, mse_loss
from onpolicy.utils.popart import PopArt
from onpolicy.algorithms.utils.util import check
from torch.autograd import Variable
from torch.nn.utils import clip_grad_norm
import pickle
import copy
class R_MAPPO():
    """
    Trainer class for MAPPO to update policies.
    :param args: (argparse.Namespace) arguments containing relevant model, policy, and env information.
    :param policy: (R_MAPPO_Policy) policy to update.
    :param device: (torch.device) specifies the device to run on (cpu/gpu).
    """
    def __init__(self,
                 args,
                 policy,
                 device=torch.device("cpu")):
        self.args = args
        self.device = device
        self.tpdv = dict(dtype=torch.float32, device=device)
        self.policy = policy
        if self.args.dynamic_clip_tag:
            self.clip_param = np.ones(self.args.n_agents)*args.clip_param
            self.clip_constant = np.log(self.clip_param + 1).sum()

            self.all_updates = int(self.args.num_env_steps) // self.args.episode_length // self.args.n_rollout_threads
            self.curr_delta_update = 0
            self.min_clip_constant = np.log(self.args.min_clip_params + 1) * self.args.n_agents
            self.curr_constant = self.clip_constant
        else:
            self.clip_param = args.clip_param




        self.value_clip_param = args.clip_param

        self.ppo_epoch = args.ppo_epoch
        self.num_mini_batch = args.num_mini_batch
        self.data_chunk_length = args.data_chunk_length
        self.value_loss_coef = args.value_loss_coef
        self.entropy_coef = args.entropy_coef
        self.max_grad_norm = args.max_grad_norm       
        self.huber_delta = args.huber_delta



        self._use_recurrent_policy = args.use_recurrent_policy
        self._use_naive_recurrent = args.use_naive_recurrent_policy
        self._use_max_grad_norm = args.use_max_grad_norm
        self._use_clipped_value_loss = args.use_clipped_value_loss
        self._use_huber_loss = args.use_huber_loss
        self._use_popart = args.use_popart
        self._use_value_active_masks = args.use_value_active_masks
        self._use_policy_active_masks = args.use_policy_active_masks
        
        if self._use_popart:
            self.value_normalizer = PopArt(1, device=self.device)
        else:
            self.value_normalizer = None


        self.log_inv_lambda_s = Variable(torch.ones([self.args.n_agents,self.args.episode_length*self.args.n_rollout_threads, 1])).to(**self.tpdv).double()
        self.log_inv_lambda_s.requires_grad = True

        self.mu_s = Variable(torch.ones([self.args.n_agents,self.args.episode_length*self.args.n_rollout_threads , 1])).to(**self.tpdv).double()
        self.mu_s.requires_grad = True

        self.opt_lambda = torch.optim.Adam([self.log_inv_lambda_s], lr=0.1)
        self.opt_mu = torch.optim.Adam([self.mu_s], lr=0.1)
        self.es_tag = False
        if self.args.penalty_method:

            self.beta_kl = self.args.beta_kl
            self.dtar_kl = self.args.dtar_kl
            self.kl_para1 = self.args.kl_para1
            self.kl_para2 = self.args.kl_para2
            self.kl_lower = self.dtar_kl / self.kl_para1
            self.kl_upper = self.dtar_kl * self.kl_para1

            if self.args.inner_refine:
                self.args.dtar_sqrt_kl = np.sqrt(self.args.dtar_kl)

            self.beta_sqrt_kl = self.args.beta_sqrt_kl
            self.dtar_sqrt_kl = self.args.dtar_sqrt_kl
            self.sqrt_kl_para1 = self.args.sqrt_kl_para1
            self.sqrt_kl_para2 = self.args.sqrt_kl_para2
            self.sqrt_kl_lower = self.dtar_sqrt_kl / self.sqrt_kl_para1
            self.sqrt_kl_upper = self.dtar_sqrt_kl * self.sqrt_kl_para1

            self.para_upper_bound = self.args.para_upper_bound
            self.para_lower_bound = self.args.para_lower_bound
            self.term_kl = None
            self.term_sqrt_kl = None

        if self.args.overflow_save:
            self.overflow = np.zeros(self.args.n_agents)
    def cal_value_loss(self, values, value_preds_batch, return_batch, active_masks_batch):
        """
        Calculate value function loss.
        :param values: (torch.Tensor) value function predictions.
        :param value_preds_batch: (torch.Tensor) "old" value  predictions from data batch (used for value clip loss)
        :param return_batch: (torch.Tensor) reward to go returns.
        :param active_masks_batch: (torch.Tensor) denotes if agent is active or dead at a given timesep.

        :return value_loss: (torch.Tensor) value function loss.
        """
        if self._use_popart:
            value_pred_clipped = value_preds_batch + (values - value_preds_batch).clamp(-self.value_clip_param,
                                                                                        self.value_clip_param)
            error_clipped = self.value_normalizer(return_batch) - value_pred_clipped
            error_original = self.value_normalizer(return_batch) - values
        else:
            value_pred_clipped = value_preds_batch + (values - value_preds_batch).clamp(-self.value_clip_param,
                                                                                        self.value_clip_param)
            error_clipped = return_batch - value_pred_clipped
            error_original = return_batch - values

        if self._use_huber_loss:
            value_loss_clipped = huber_loss(error_clipped, self.huber_delta)
            value_loss_original = huber_loss(error_original, self.huber_delta)
        else:
            value_loss_clipped = mse_loss(error_clipped)
            value_loss_original = mse_loss(error_original)

        if self._use_clipped_value_loss:
            value_loss = torch.max(value_loss_original, value_loss_clipped)
        else:
            value_loss = value_loss_original

        if self._use_value_active_masks:
            value_loss = (value_loss * active_masks_batch).sum() / active_masks_batch.sum()
        else:
            value_loss = value_loss.mean()

        return value_loss

    def ppo_update(self, sample, update_actor=True,aga_update_tag = False,update_index = -1,curr_update_num=None):
        """
        Update actor and critic networks.
        :param sample: (Tuple) contains data batch with which to update networks.
        :update_actor: (bool) whether to update actor network.

        :return value_loss: (torch.Tensor) value function loss.
        :return critic_grad_norm: (torch.Tensor) gradient norm from critic up9date.
        ;return policy_loss: (torch.Tensor) actor(policy) loss value.
        :return dist_entropy: (torch.Tensor) action entropies.
        :return actor_grad_norm: (torch.Tensor) gradient norm from actor update.
        :return imp_weights: (torch.Tensor) importance sampling weights.
        """
        base_ret,q_ret,sp_ret,penalty_ret = sample
        share_obs_batch, obs_batch, rnn_states_batch, rnn_states_critic_batch, actions_batch, \
        value_preds_batch, return_batch, masks_batch, active_masks_batch, old_action_log_probs_batch, \
        adv_targ, available_actions_batch = base_ret




        # print('share_obs_batch = {}'.format(share_obs_batch.shape))
        # print('obs_batch = {}'.format(share_obs_batch.shape))

        old_action_log_probs_batch = check(old_action_log_probs_batch).to(**self.tpdv)
        adv_targ = check(adv_targ).to(**self.tpdv)
        value_preds_batch = check(value_preds_batch).to(**self.tpdv)
        return_batch = check(return_batch).to(**self.tpdv)
        active_masks_batch = check(active_masks_batch).to(**self.tpdv)
        # print('active_masks = {}'.format(active_masks_batch.shape))
        # Reshape to do in a single forward pass for all steps
        # print('aga_update_tag = {}, update_index = {}'.format(aga_update_tag,update_index))
        if self.args.idv_para and aga_update_tag and self.args.aga_tag:
            # print('case1')
            values_all, action_log_probs, dist_entropy = self.policy.evaluate_actions_single(share_obs_batch,
                                                                                  obs_batch,
                                                                                  rnn_states_batch,
                                                                                  rnn_states_critic_batch,
                                                                                  actions_batch,
                                                                                  masks_batch,
                                                                                  available_actions_batch,
                                                                                  active_masks_batch,update_index=update_index)
        else:
            prob_merge_tag = not self.args.dynamic_clip_tag
            values_all, action_log_probs, dist_entropy = self.policy.evaluate_actions(share_obs_batch,
                                                                                  obs_batch,
                                                                                  rnn_states_batch,
                                                                                  rnn_states_critic_batch,
                                                                                  actions_batch,
                                                                                  masks_batch,
                                                                                  available_actions_batch,
                                                                                  active_masks_batch,prob_merge=prob_merge_tag)
        # actor update
        #imp_weights = (episode_length * agent_num, 1)
        # imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)
        # print('imp_weights = {}'.format(imp_weights.shape))
        self.es_tag = False
        if self.args.penalty_method:
            eps_kl = 1e-9
            eps_sqrt = 1e-12
            if self.args.env_name == 'mujoco':
                if self.args.sp_use_q:
                    sp_prob,sp_target_prob = [], []
                    for i in range(self.args.sp_num):
                        value, action_new, action_log_prob, rnn_state, rnn_state_critic \
                            = self.policy.get_actions(share_obs_batch,
                                                              obs_batch,
                                                              rnn_states_batch,
                                                              rnn_states_critic_batch,
                                                              masks_batch, available_actions=available_actions_batch)

                        prob_merge_tag = not self.args.dynamic_clip_tag
                        target_value, target_action_log_probs, target_dist_entropy = self.policy.evaluate_actions(share_obs_batch,
                                                                                                  obs_batch,
                                                                                                  rnn_states_batch,
                                                                                                  rnn_states_critic_batch,
                                                                                                  action_new,
                                                                                                  masks_batch,
                                                                                                  available_actions_batch,
                                                                                                  active_masks_batch,
                                                                                                  prob_merge=prob_merge_tag,target=True)



                        if self.args.sp_check:
                            print('sp {}: value = {}, action = {}  action_log_prob = {}'.format(i, value, action_new,
                                                                                                action_log_prob))
                        sp_prob.append(action_log_prob)
                        sp_target_prob.append(target_action_log_probs)

                    sp_prob = torch.stack(sp_prob, dim=-1)
                    sp_prob = F.softmax(sp_prob,dim = -1)
                    sp_target_prob = torch.stack(sp_target_prob, dim=-1)
                    sp_target_prob = F.softmax(sp_target_prob, dim=-1)
                    sp_target_prob = sp_target_prob.detach()

                    kl = sp_target_prob * (torch.log(sp_target_prob + eps_kl) - torch.log(sp_prob + eps_kl) )
                    kl = torch.sum(kl,dim = -1,keepdim=True).reshape([-1,1])
                else:
                    with torch.no_grad():
                        old_dist = self.policy.get_dist(obs_batch, rnn_states_batch, masks_batch,target=True)
                    new_dist = self.policy.get_dist(obs_batch, rnn_states_batch, masks_batch)
                    kl = []
                    for idv_old,idv_new in zip(old_dist,new_dist):
                        idv_kl = torch.distributions.kl_divergence(idv_old,idv_new)
                        kl.append(idv_kl)
                    kl = torch.stack(kl,dim = 1)
                    # print('n_actions = {} kl = {}, idv_kl = {}'.format(self.args.n_actions,kl.shape,idv_kl.shape))
            else:
                if self.args.env_name == 'StarCraft2':
                    probs = self.policy.get_probs(obs_batch, rnn_states_batch, masks_batch,available_actions=available_actions_batch)
                else:
                    probs = self.policy.get_probs(obs_batch, rnn_states_batch, masks_batch)


                old_probs_batch = penalty_ret[0]

                old_probs_batch = check(old_probs_batch).to(**self.tpdv)

                # print('n_actions = {} old_probs_batch = {}, probs = {}'.format(self.args.n_actions,old_probs_batch.shape,probs.shape))
                kl = old_probs_batch * (torch.log(old_probs_batch + eps_kl) - torch.log(probs + eps_kl) )

            kl = torch.sum(kl,dim = -1,keepdim=True).reshape([-1,1])

            imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)
            term1 = imp_weights * adv_targ
            if not self.args.early_stop:
                sqrt_kl = torch.sqrt(torch.max(kl + eps_sqrt,eps_sqrt * torch.ones_like(kl)))
                if self.args.check_kl_output:
                    kl_1 = old_probs_batch * torch.log(old_probs_batch + eps_kl)
                    kl_2 = old_probs_batch * torch.log(probs + eps_kl)
                    arr_length = kl.shape[0]
                    kl_1 = kl_1.reshape([arr_length, -1])
                    kl_2 = kl_2.reshape([arr_length, -1])
                    for i in range(kl.shape[0]):
                        print(
                            'kl_term[{}] = {}, kl_1[{}] = {}, kl_2[{}] = {} kl+eps_sqrt = {}, sqrt ={}'.format(i, kl[i][0],
                                                                                                               i, kl_1[i],
                                                                                                               i, kl_2[i],
                                                                                                               kl[i][
                                                                                                                   0] + eps_sqrt,
                                                                                                               torch.sqrt(
                                                                                                                   kl[i][
                                                                                                                       0] + eps_sqrt)))
                    print('eps_sqrt = {}'.format(eps_sqrt))
                    for i in range(kl.shape[0]):
                        print('sqrt_kl_term[{}] = {}'.format(i, sqrt_kl[i]))

                if self._use_policy_active_masks:
                    term1 = (-torch.sum(term1,dim=-1,keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
                    # print('kl = {} sqrt_kl = {} active_masks = {}'.format(kl.shape,sqrt_kl.shape,active_masks_batch.shape))
                    term_sqrt_kl = (torch.sum(sqrt_kl,dim=-1,keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
                    term_kl = (torch.sum(kl, dim=-1, keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
                else:
                    term1 = -torch.sum(term1, dim=-1, keepdim=True).mean()
                    term_sqrt_kl = torch.sum(sqrt_kl, dim=-1, keepdim=True).mean()
                    term_kl = torch.sum(kl, dim=-1, keepdim=True).mean()
                self.term_sqrt_kl = term_sqrt_kl
                self.term_kl = term_kl
                policy_loss = term1 + self.beta_sqrt_kl * term_sqrt_kl + self.beta_kl * term_kl
                self.es_tag = False
            else:
                if self._use_policy_active_masks:
                    term1 = (-torch.sum(term1,dim=-1,keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
                else:
                    term1 = -torch.sum(term1, dim=-1, keepdim=True).mean()
                policy_loss = term1
                self.es_kl.append(torch.mean(kl))
            clip_rate = 0
        else:
            if self.args.dynamic_clip_tag:
                if self.args.idv_para and aga_update_tag and self.args.aga_tag:
                    imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)
                    surr1 = imp_weights * adv_targ
                    surr2 = torch.clamp(imp_weights, 1.0 - self.clip_param[update_index], 1.0 + self.clip_param[update_index]) * adv_targ
                else:
                    surr1 = []
                    surr2 = []
                    agent_adv_targ = adv_targ.reshape([-1, self.args.n_agents, 1])
                    if self.args.env_name == 'mujoco':
                        old_action_log_probs_batch = old_action_log_probs_batch.mean(axis = -1)
                    agent_old_action_log_probs = old_action_log_probs_batch.reshape([-1, self.args.n_agents, 1])
                    # print('init_agent_old_action_log_probs = {},agent_old_action_log_probs = {}'.format(old_action_log_probs_batch.shape,agent_old_action_log_probs.shape))
                    # print('old_batch = {}'.format(old_action_log_probs_batch))
                    imp_weights = []
                    for i in range(self.args.n_agents):
                        # print('action_log_probs[{}] = {},  agent_old_action_log_probs[:, {}] = {}'.format(i,action_log_probs[i].shape,i,agent_old_action_log_probs[:, i].shape ))

                        agent_imp_weights = torch.exp(action_log_probs[i] - agent_old_action_log_probs[:, i])
                        agent_surr1 = agent_imp_weights * agent_adv_targ[:, i]
                        agent_surr2 = torch.clamp(agent_imp_weights, 1.0 - self.clip_param[i],
                                                  1.0 + self.clip_param[i]) * agent_adv_targ[:, i]
                        surr1.append(agent_surr1)
                        surr2.append(agent_surr2)
                        imp_weights.append(agent_imp_weights)
                    surr1 = torch.stack(surr1, dim=1).reshape([-1, 1])
                    surr2 = torch.stack(surr2, dim=1).reshape([-1, 1])
                    imp_weights = torch.stack(imp_weights, dim=1).reshape([-1, 1])
            else:
                imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)
                surr1 = imp_weights * adv_targ
                surr2 = torch.clamp(imp_weights, 1.0 - self.clip_param, 1.0 + self.clip_param) * adv_targ
            clip_check = (surr1 != surr2)
            clip_check_sum = clip_check.sum()
            clip_check_total = torch.ones_like(clip_check).sum()
            # print('clip_check = {}'.format(clip_check))
            # print('clip_check_sum = {}'.format(clip_check_sum))
            # print('clip_check_total = {}'.format(clip_check_total))
            clip_rate = float(clip_check_sum) / float(clip_check_total)
            print('clip_rate = {}'.format(clip_rate))

            if self._use_policy_active_masks:
                policy_action_loss = (-torch.sum(torch.min(surr1, surr2),
                                                 dim=-1,
                                                 keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
            else:
                policy_action_loss = -torch.sum(torch.min(surr1, surr2), dim=-1, keepdim=True).mean()

            policy_loss = policy_action_loss


        if self.args.idv_para:
            if aga_update_tag and self.args.aga_tag:
                self.policy.actor_optimizer[update_index].zero_grad()
            else:
                for i in range(self.args.n_agents):
                    self.policy.actor_optimizer[i].zero_grad()
        else:
            self.policy.actor_optimizer.zero_grad()

        if update_actor:
            (policy_loss - dist_entropy * self.entropy_coef).backward()

        if self._use_max_grad_norm:
            if self.args.idv_para:
                if aga_update_tag and self.args.aga_tag:
                    actor_grad_norm = nn.utils.clip_grad_norm_(self.policy.actor[update_index].parameters(), self.max_grad_norm)
                else:
                    actor_grad_norm = 0
                    for i in range(self.args.n_agents):
                        idv_actor_grad_norm = nn.utils.clip_grad_norm_(self.policy.actor[i].parameters(),
                                                                   self.max_grad_norm)
                        actor_grad_norm += idv_actor_grad_norm
                    actor_grad_norm /= self.args.n_agents

            else:
                actor_grad_norm = nn.utils.clip_grad_norm_(self.policy.actor.parameters(), self.max_grad_norm)
        else:
            if self.args.idv_para:
                if aga_update_tag and self.args.aga_tag:
                    actor_grad_norm = get_gard_norm(self.policy.actor[update_index].parameters())
                else:
                    actor_grad_norm = 0
                    for i in range(self.args.n_agents):
                        idv_actor_grad_norm = get_gard_norm(self.policy.actor[i].parameters())
                        actor_grad_norm += idv_actor_grad_norm
                    actor_grad_norm /= self.args.n_agents

            else:
                actor_grad_norm = get_gard_norm(self.policy.actor.parameters())




        if self.args.idv_para:
            if aga_update_tag and self.args.aga_tag:
                self.policy.actor_optimizer[update_index].step()
            else:
                for i in range(self.args.n_agents):
                    self.policy.actor_optimizer[i].step()
        else:
            self.policy.actor_optimizer.step()

        # critic update
        if self.args.use_q:
            act_idx = torch.from_numpy(actions_batch).to(**self.tpdv)
            act_idx = act_idx.long()
            # act_idx =
            # print('act_idx.dtype = {} act_idx = {} values = {}'.format(act_idx.dtype,act_idx.shape,values.shape))
            values = torch.gather(values_all,index = act_idx,dim = -1)
        else:
            values = values_all

        value_loss = self.cal_value_loss(values, value_preds_batch, return_batch, active_masks_batch)

        if self.args.idv_para:
            if aga_update_tag and self.args.aga_tag:
                self.policy.critic_optimizer[update_index].zero_grad()
            else:
                for i in range(self.args.n_agents):
                    self.policy.critic_optimizer[i].zero_grad()
        else:
            self.policy.critic_optimizer.zero_grad()

        (value_loss * self.value_loss_coef).backward()

        if self._use_max_grad_norm:
            if self.args.idv_para:
                if aga_update_tag and self.args.aga_tag:
                    critic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic[update_index].parameters(),
                                                               self.max_grad_norm)
                else:
                    critic_grad_norm = 0
                    for i in range(self.args.n_agents):
                        idv_critic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic[i].parameters(),
                                                                       self.max_grad_norm)
                        critic_grad_norm += idv_critic_grad_norm
                    critic_grad_norm /= self.args.n_agents

            else:
                critic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic.parameters(), self.max_grad_norm)
        else:
            if self.args.idv_para:
                if aga_update_tag and self.args.aga_tag:
                    critic_grad_norm = get_gard_norm(self.policy.critic[update_index].parameters())
                else:
                    critic_grad_norm = 0
                    for i in range(self.args.n_agents):
                        idv_critic_grad_norm = get_gard_norm(self.policy.critic[i].parameters())
                        critic_grad_norm += idv_critic_grad_norm
                    critic_grad_norm /= self.args.n_agents

            else:
                critic_grad_norm = get_gard_norm(self.policy.critic.parameters())


        if self.args.idv_para:
            if aga_update_tag and self.args.aga_tag:
                self.policy.critic_optimizer[update_index].step()
            else:
                for i in range(self.args.n_agents):
                    self.policy.critic_optimizer[i].step()
        else:
            self.policy.critic_optimizer.step()

        # if self.args.dynamic_clip_tag and self.args.use_q and curr_update_num < self.args.clip_update_num:
        #     # all_probs = self.policy.get_probs(obs_batch,rnn_states_batch, masks_batch,available_actions_batch)
        #     old_A = old_values_batch - baseline_batch
        #     self.update_policy_clip(old_probs_batch,old_A)

        return value_loss, critic_grad_norm, policy_loss, dist_entropy, actor_grad_norm, imp_weights,clip_rate
    def update_policy_clip_ver_1(self,pi,A):
        np_delta = np.log(1 + self.clip_param)
        if self.args.overflow_save:
            np_delta += self.overflow
            self.overflow = np.zeros_like(np_delta)
        np_delta = np.expand_dims(np_delta, axis=1).astype(np.float64)

        data_for_save = {}
        data_for_save['pi'] = pi
        data_for_save['A'] = A
        data_for_save['delta'] = np_delta

        pi = torch.from_numpy(pi).detach().double().to(**self.tpdv)
        A = torch.from_numpy(A).detach().double().to(**self.tpdv)

        print('pi_device = {}'.format(pi.device))
        if self.args.sp_clip:
            clip_n_actions = self.args.sp_num
        else:
            clip_n_actions = self.args.n_actions
        init_A = A.reshape([-1,self.args.n_agents,clip_n_actions]).permute(1,0,2).double()
        pi = pi.reshape([-1, self.args.n_agents, clip_n_actions]).permute(1, 0, 2).double()
        max_A = torch.max( torch.abs(init_A), dim=-1, keepdim=True)[0].double()
        # print('init_A = {} std_A = {}'.format(init_A.dtype,std_A.dtype))
        A = init_A / max_A



        delta_sum = np_delta.sum()
        max_delta = np.log(1 + self.args.clip_delta_max_eps)
        min_delta = np.log(1 + self.args.clip_delta_min_eps)
        delta = torch.from_numpy(np_delta).to(pi.device)

        self.log_inv_lambda_s = Variable(
            torch.ones([self.args.n_agents, self.args.episode_length * self.args.n_rollout_threads, 1])).to(
            **self.tpdv).double()
        self.log_inv_lambda_s.requires_grad = True

        self.mu_s = Variable(
            torch.ones([self.args.n_agents, self.args.episode_length * self.args.n_rollout_threads, 1])).to(
            **self.tpdv).double()
        self.mu_s.requires_grad = True

        # self.log_inv_lambda_s.data = torch.ones([self.args.n_agents,self.args.episode_length*self.args.n_rollout_threads, 1]).to(**self.tpdv).double()
        # self.mu_s.data = torch.ones([self.args.n_agents, self.args.episode_length*self.args.n_rollout_threads, 1]).to(**self.tpdv).double()
        if self.args.joint_optim:
            self.opt_joint = torch.optim.RMSprop([self.log_inv_lambda_s,self.mu_s], lr=0.1)
        else:
            self.opt_lambda = torch.optim.RMSprop([self.log_inv_lambda_s], lr=0.1)
            self.opt_mu = torch.optim.RMSprop([self.mu_s], lr=0.1)
        L = 10000
        best_loss = 10000
        best_iter = 0
        best_solution = self.log_inv_lambda_s.detach().clone()
        eps = self.args.solve_eps
        iter_cnt = 0
        max_iter = self.args.solve_max_iter
        while L > eps and iter_cnt < max_iter:

            inv_lambda_s = -torch.exp(self.log_inv_lambda_s)
            if not self.args.joint_optim:
            # print('A = {} self.mu_s = {} inv_lambda_s = {}'.format(A.dtype,self.mu_s.dtype, inv_lambda_s.dtype))
                u = -((A + self.mu_s.detach()) * inv_lambda_s + 1)
                exp_u = torch.exp(u)
                L1 = pi * exp_u * u
                L1 = L1.sum(dim=-1)
                L1 = ((L1 - delta) ** 2).mean()
                self.opt_lambda.zero_grad()
                L1.backward()
                # print('grad = {}'.format(lambda_s.grad))
                clip_grad_norm([self.log_inv_lambda_s], max_norm=10)
                self.opt_lambda.step()

                u = -((A + self.mu_s) * inv_lambda_s.detach() + 1)
                exp_u = torch.exp(u)
                L2 = pi * exp_u
                L2 = L2.sum(dim=-1)
                L2 = ((L2 - 1) ** 2).mean()

                self.opt_mu.zero_grad()
                L2.backward()
                # print('grad = {}'.format(lambda_s.grad))
                clip_grad_norm([self.mu_s], max_norm=10)
                self.opt_mu.step()
                L = L1 + L2
            else:
                u = -((A + self.mu_s) * inv_lambda_s + 1)
                exp_u = torch.exp(u)
                L1 = pi * exp_u * u
                L1 = L1.sum(dim=-1)
                L1 = ((L1 - delta) ** 2).mean()
                L2 = pi * exp_u
                L2 = L2.sum(dim=-1)
                L2 = ((L2 - 1) ** 2).mean()
                L = L1 + L2
                self.opt_joint.zero_grad()
                L.backward()
                clip_grad_norm([self.log_inv_lambda_s, self.mu_s], max_norm=10)
                self.opt_joint.step()
            iter_cnt += 1
            if L < best_loss:
                best_loss = L
                best_solution = self.log_inv_lambda_s.detach().clone()
                best_iter = iter_cnt
            if self.args.solve_check:
                print('curr_iteration = {} curr_loss = {} best_iteration = {} best_loss = {}'.format(iter_cnt,L,best_iter, best_loss))
            if iter_cnt - best_iter >= self.args.tol_iteration:
                break

        if self.args.save_not_solved:
            with open('not_solved_data.pkl','wb') as f:
                pickle.dump(data_for_save,f)

        # lambda_s = -torch.exp(-self.log_inv_lambda_s)
        lambda_s = -torch.exp(-best_solution)
        # print('lambda_s = {}'.format(lambda_s))
        lambda_s *= max_A
        lambda_s = lambda_s.squeeze(-1)
        delta_grad = -lambda_s.mean(dim = -1,keepdim= True).detach().cpu().numpy()

        if self.args.lucky_guy:
            lucky_guy = np.random.choice(np.arange(self.args.n_agents))
        else:
            lucky_guy = -1

        delta_grad = delta_grad - delta_grad[lucky_guy]
        step_size = self.args.clip_param_lr
        lr_decay = self.args.clip_lr_decay
        old_sum = np.sum(np_delta[:-1])
        add_sum = np.sum(delta_grad[:-1])

        linear_seach_step = 0
        while True:
            new_delta = np_delta + step_size * delta_grad
            min_judge_delta = np.min(new_delta)
            new_sum = old_sum + step_size * add_sum
            if min_judge_delta >= 0 and new_sum <= delta_sum:
                break
            else:
                step_size *= lr_decay
            linear_seach_step += 1
            if self.args.linear_search_check:
                print('linear_search_step = {} step_size = {} new_delta = {}, old_delta = {}, delta_grad = {} new_sum = {}, delta_sum = {}'.format(linear_seach_step,step_size,new_delta,np_delta,delta_grad,new_sum,delta_sum))
            if linear_seach_step > 100:
                print('linear_search_failed')
                break
        new_delta = new_delta.squeeze(axis = -1)
        new_delta[-1] = delta_sum - new_sum
        constant_before_clip = np.sum(new_delta)
        if self.args.clip_delta_smooth:
            new_delta_smooth = copy.deepcopy(new_delta)
            clip_smooth_step = 0
            while True:
                new_delta_clip = np.clip(new_delta_smooth, min_delta, max_delta)
                gap = new_delta_smooth - new_delta_clip
                not_clipped_one = (gap == 0)
                not_clipped_cnt = not_clipped_one.sum()
                low_clipped_one = (gap < 0)
                high_clipped_one = (gap > 0)

                clipped_cnt = len(gap) - not_clipped_cnt
                if clipped_cnt == 0:
                    break
                else:
                    if self.args.overflow_save:
                        low_gap_sum = (gap * low_clipped_one).sum()
                        not_low_clipped_cnt = len(gap) - low_clipped_one.sum()
                        not_low_clipped_one = not_clipped_one + high_clipped_one
                        new_delta_smooth = new_delta_clip + low_gap_sum / not_low_clipped_cnt * not_low_clipped_one

                        high_gap_sum = (gap * high_clipped_one).sum()
                        not_high_clipped_cnt = len(gap) - high_clipped_one.sum()
                        not_high_clipped_one = not_clipped_one + low_clipped_one
                        self.overflow += (high_gap_sum / not_high_clipped_cnt * not_high_clipped_one)
                    else:
                        gap_sum = gap.sum()
                        new_delta_smooth = new_delta_clip + gap_sum / not_clipped_cnt * not_clipped_one
                clip_smooth_step += 1
                print('clip_smooth_step = {} new_delta = {}, new_delta_smooth = {}, new_delta_clip = {}, gap = {}, not_clipped_one = {},\
                                    clipped_cnt = {}'.format(clip_smooth_step,new_delta, new_delta_smooth, \
                                                             new_delta_clip, gap, not_clipped_one, clipped_cnt))
                if clip_smooth_step > 100:
                    print('clip_smooth_step failed')
                    print('new_delta = {}, new_delta_smooth = {}, new_delta_clip = {}, gap = {}, not_clipped_one = {},\
                    clipped_cnt = {}'.format(new_delta , new_delta_smooth , \
                                             new_delta_clip , gap , not_clipped_one,clipped_cnt))
                    break
            new_delta_clip = new_delta_smooth
        # new_delta_clip = np.clip(new_delta,min_delta,max_delta)
        else:
            new_delta_clip = new_delta
        constant_after_clip = np.sum(new_delta)
        min_eps = np.exp(min_delta) - 1
        max_eps = np.exp(max_delta) - 1
        self.clip_delta = new_delta_clip
        new_epsilon = np.exp(new_delta_clip) - 1
        print('clip_adjust: final_iteration {} best_iteration = {} final_loss = {} old_epsilon = {},\
         new_epsilon = {},min_eps = {},max_eps= {},step_size = {} lucky_guy = {}'.format(\
            iter_cnt,best_iter, best_loss,self.clip_param,new_epsilon,\
            min_eps,max_eps,step_size,lucky_guy))
        print('init_constant = {} constant_before_clip = {} constant_after_clip = {}'.format(self.clip_constant,constant_before_clip,constant_after_clip))
        self.clip_param = new_epsilon
        return iter_cnt,best_loss
    def update_policy_clip_ver_2(self,pi,A,rho_s = None):


        data_for_save = {}
        data_for_save['pi'] = pi
        data_for_save['A'] = A


        pi = torch.from_numpy(pi).detach().double().to(**self.tpdv)
        A = torch.from_numpy(A).detach().double().to(**self.tpdv)
        if self.args.dc_check_output:
            print('pi_device = {}'.format(pi.device))
        if self.args.sp_clip:
            clip_n_actions = self.args.sp_num
        else:
            clip_n_actions = self.args.n_actions
        init_A = A.reshape([-1,self.args.n_agents,clip_n_actions]).permute(1,0,2).double()
        pi = pi.reshape([-1, self.args.n_agents, clip_n_actions]).permute(1, 0, 2).double()
        if self.args.dcmode2_save:
            for a in range(self.args.n_agents):
                for i in range(pi.shape[1]):
                    print('state {} agent {}: A = {} pi = {}'.format(i, a, init_A[a,i],pi[a,i]))
        max_A = torch.max( torch.abs(init_A), dim=-1, keepdim=True)[0].double()
        # print('init_A = {} std_A = {}'.format(init_A.dtype,std_A.dtype))
        A = init_A / max_A

        opt_lambda_list, opt_mu_list, opt_delta_list = [], [], []
        all_log_inv_lambda_s, all_mu_s, all_log_delta = [], [], []
        state_num = pi.shape[1]
        for i in range(self.args.n_agents):
            log_inv_lambda_s = Variable(torch.ones([state_num, 1])).to(pi.device).double()
            log_inv_lambda_s.requires_grad = True

            mu_s = Variable(torch.ones([state_num, 1])).to(pi.device).double()
            mu_s.requires_grad = True

            log_delta = Variable(torch.zeros([1])).to(pi.device).double()
            log_delta += np.log(np.log(1.5))
            log_delta.requires_grad = True

            opt_lambda_i = torch.optim.RMSprop([log_inv_lambda_s], lr=0.1)
            opt_mu_i = torch.optim.RMSprop([mu_s], lr=0.1)
            opt_delta_i = torch.optim.RMSprop([log_delta], lr=0.1)
            opt_lambda_list.append(opt_lambda_i)
            opt_mu_list.append(opt_mu_i)
            opt_delta_list.append(opt_delta_i)
            all_log_inv_lambda_s.append(log_inv_lambda_s)
            all_mu_s.append(mu_s)
            all_log_delta.append(log_delta)

        gamma = self.args.gamma
        n_agents = self.args.n_agents
        const_C = 6 * gamma / (1 - gamma)
        coeff_vec = torch.zeros([state_num])
        if rho_s is None:
            coeff_vec[0] = 1
            for i in range(1, state_num):
                coeff_vec[i] = gamma * coeff_vec[i - 1]
        else:
            coeff_vec = torch.tensor(rho_s)
        coeff_vec = coeff_vec.unsqueeze(-1).unsqueeze(0).repeat([self.args.n_agents, 1, 1]).to(pi.device).double()
        L = 10000
        best_loss = 10000
        best_iter = 0
        eps = self.args.solve_eps
        iter_cnt = 0
        max_iter = self.args.solve_max_iter
        loss_coeff_1, loss_coeff_2, loss_coeff_3 = 1, 1, self.args.L3_coeff
        min_loss = 1000000000000 * np.ones(n_agents)
        last_update_min_loss = np.zeros(n_agents)
        best_delta = np.zeros(n_agents)
        all_end = np.array([False for i in range(n_agents)])
        tol_duration = self.args.tol_iteration
        loss_for_save = [ {'L1':100000,'L2':100000,'L3':100000} for i in range(n_agents)]
        while True:
            for i in range(n_agents):
                if all_end[i]:
                    continue
                log_inv_lambda_s, mu_s, log_delta = all_log_inv_lambda_s[i], all_mu_s[i], all_log_delta[i]
                inv_lambda_s = torch.exp(log_inv_lambda_s)
                lambda_s = torch.exp(-log_inv_lambda_s)
                A_i = A[i]
                pi_i = pi[i]
                delta = torch.exp(log_delta)
                u = -((A_i + mu_s) * inv_lambda_s + 1)
                exp_u = torch.exp(u)
                if self.args.sp_clip:
                    L1 = exp_u * u
                    L1 = L1.mean(dim=-1)
                    L2 = exp_u
                    L2 = L2.mean(dim=-1)
                else:
                    L1 = pi_i * exp_u * u
                    L1 = L1.sum(dim=-1)
                    L2 = pi_i * exp_u
                    L2 = L2.sum(dim=-1)
                L1 = ((L1 - delta) ** 2).sum()
                L2 = ((L2 - 1) ** 2).sum()
                # print('coeff_vec = {} lambda_s = {}'.format(coeff_vec.device,lambda_s.device))
                L3 = (coeff_vec * lambda_s).squeeze(-1)
                L3 = L3.sum(dim=-1)
                inv_sqrt_delta = torch.exp(-0.5*log_delta)
                L3 = (0.5*inv_sqrt_delta*const_C - L3) ** 2
                L3 = L3.sum()
                L = loss_coeff_1 * L1 + loss_coeff_2 * L2 + loss_coeff_3 * L3
                if self.args.dynamic_l3:
                    loss_coeff_3 = 0.1 * ( L1 + L2) / 2.0 / L3 + 0.9 * loss_coeff_3
                opt_lambda_list[i].zero_grad()
                opt_mu_list[i].zero_grad()
                opt_delta_list[i].zero_grad()

                L.backward()
                clip_grad_norm([log_inv_lambda_s, mu_s, log_delta], max_norm=10)

                opt_lambda_list[i].step()
                opt_mu_list[i].step()
                opt_delta_list[i].step()
                check_L = L.item()
                if check_L < min_loss[i]:
                    last_update_min_loss[i] = iter_cnt
                    min_loss[i] = check_L
                    best_delta[i] = delta.detach().cpu().numpy()[0]
                    loss_for_save[i] = {'L1':L1.item(),'L2':L2.item(),'L3':L3.item()}
                iter_cnt += 1
                clip_para = torch.exp(delta) - 1
                if self.args.dc_check_output:
                    print('iteration {} agent {}: loss = {} L1 = {} L2 = {} L3 = {},delta = {} eps = {}'.format(iter_cnt, i,
                                                                                                                L, L1, L2,
                                                                                                                L3,
                                                                                                                delta[0],
                                                                                                                clip_para[
                                                                                                                    0]))
                    print('check_L = {} eps = {}'.format(check_L, eps))

                if check_L <= eps:
                    print('precision is ensured for agent {}'.format(i))
                    all_end[i] = True
                if iter_cnt - last_update_min_loss[i] >= tol_duration:
                    print('tolarance has run out for agent {}'.format(i))
                    all_end[i] = True
                if iter_cnt >= max_iter:
                    print('max iteration {} has run out for agent {}'.format(max_iter, i))
                    all_end[i] = True
            if all(all_end):
                break

        if self.args.dcmode2_save:
            for i in range(self.args.n_agents):
                for k in loss_for_save[i]:
                    print('agent {}: {} = {}'.format(i,k,loss_for_save[i][k]))

            if self.args.dynamic_l3:
                print('l3_coeff = {}'.format(loss_coeff_3))

        if self.args.save_not_solved:
            with open('not_solved_data.pkl','wb') as f:
                pickle.dump(data_for_save,f)


        self.clip_delta = best_delta
        new_epsilon = np.exp(best_delta) - 1
        print('clip_adjust: final_iteration {} best_iteration = {} final_loss = {} old_epsilon = {},\
         new_epsilon = {}'.format(\
            iter_cnt,last_update_min_loss, min_loss,self.clip_param,new_epsilon,))

        self.clip_param = new_epsilon
        return last_update_min_loss.mean(),min_loss.mean()
    def train(self, buffer, update_actor=True,time_steps=None):
        """
        Perform a training update using minibatch GD.
        :param buffer: (SharedReplayBuffer) buffer containing training data.
        :param update_actor: (bool) whether to update actor network.

        :return train_info: (dict) contains information regarding training update (e.g. loss, grad norms, etc).
        """
        if self.args.penalty_method and self.term_kl is not None:
            print('term_sqrt_kl = {} term_kl = {} old_beta_sqrt_kl = {}, old_beta_kl = {}'.format(self.term_sqrt_kl,
                                                                                                  self.term_kl,
                                                                                                  self.beta_sqrt_kl,
                                                                                                  self.beta_kl))
            print('prev beta_kl = {}'.format(self.beta_kl))
            if self.args.penalty_beta_type == 'adaptive':
                if self.term_kl < self.kl_lower:
                    self.beta_kl /= self.kl_para2
                    # self.beta_kl = np.maximum(self.para_lower_bound,self.beta_kl)
                elif self.term_kl > self.kl_upper:
                    self.beta_kl *= self.kl_para2
                    # self.beta_kl = np.minimum(self.para_upper_bound, self.beta_kl)
                print('after beta_kl = {}'.format(self.beta_kl))

            if self.args.penalty_beta_sqrt_type == 'adaptive':
                if self.term_sqrt_kl < self.sqrt_kl_lower:
                    self.beta_sqrt_kl /= self.sqrt_kl_para2
                    # self.beta_sqrt_kl = np.maximum(self.para_lower_bound, self.beta_sqrt_kl)

                elif self.term_sqrt_kl > self.sqrt_kl_upper:
                    self.beta_sqrt_kl *= self.sqrt_kl_para2
                    # self.beta_sqrt_kl = np.minimum(self.para_upper_bound, self.beta_sqrt_kl)

            elif self.args.penalty_beta_type == 'adaptive_rule2':
                if self.args.use_q:
                    old_pi = buffer.old_probs_all[:-1]

                    # (39,1,3,5) (episode_length,rollout_thread,agents, actions)
                    old_pi = old_pi.reshape(-1, self.args.n_actions)
                    old_q = buffer.old_values_all[:-1]
                    # print('old_q_shape = {}'.format(old_q.shape))
                    old_q = old_q.reshape(-1, self.args.n_actions)
                    old_baseline = buffer.baseline[:-1]
                    old_baseline = old_baseline.reshape(-1, 1)
                    old_A = old_q - old_baseline
                    E_A_square = old_A * old_A * old_pi
                    E_A_square = 2 * np.sqrt( np.sum(E_A_square) )
                elif self.args.sp_use_q:
                    old_pi = buffer.sp_prob_all[:-1]

                    # (39,1,3,5) (episode_length,rollout_thread,agents, actions)
                    old_pi = old_pi.reshape(-1, self.args.sp_num)
                    old_q = buffer.sp_value_all[:-1]
                    # print('old_q_shape = {}'.format(old_q.shape))
                    old_q = old_q.reshape(-1, self.args.sp_num)
                    old_baseline = np.mean(old_q, axis=-1, keepdims=True)
                    old_A = old_q - old_baseline
                    E_A_square = old_A * old_A
                    E_A_square = 2 * np.sqrt(np.mean(E_A_square))
                self.beta_sqrt_kl = 0.9 * E_A_square
                print('before_ramge_clip: new_beta_sqrt_kl = {}'.format(self.beta_sqrt_kl))

            if self.beta_kl < self.para_lower_bound:
                self.beta_kl = self.para_lower_bound
            if self.beta_kl > self.para_upper_bound:
                self.beta_kl = self.para_upper_bound
            if self.beta_sqrt_kl < self.para_lower_bound:
                self.beta_sqrt_kl = self.para_lower_bound
            if self.beta_sqrt_kl > self.para_upper_bound:
                self.beta_sqrt_kl = self.para_upper_bound

            print('after_ramge_clip: new_beta_sqrt_kl = {}'.format(self.beta_sqrt_kl))

            if self.args.no_sqrt_kl:
                self.beta_sqrt_kl = 0

            print('new_beta_sqrt_kl = {}, new_beta_kl = {}'.format(self.beta_sqrt_kl, self.beta_kl))

        if self.args.dynamic_clip_tag:
            if self.args.use_q:
                if self.args.all_state_clip:

                    eye = np.eye(self.args.obs_shape)
                    old_q = []
                    old_pi = []
                    for i in range(self.args.obs_shape):
                        obs_input = []
                        share_obs_input = []
                        for a in range(self.args.n_agents):
                            obs_input.append(eye[i])
                            share_obs_input.append(eye[i])
                        obs_input = np.array(obs_input)
                        share_obs_input = np.array(share_obs_input)
                        masks_inputs = np.ones([self.args.n_agents,1])
                        rnn_states_input = np.zeros([self.args.n_agents,1,self.args.hidden_size])
                        rnn_states_critic_inputs = np.zeros([self.args.n_agents, 1, self.args.hidden_size])

                        value, action, action_log_prob, rnn_state, rnn_state_critic\
                            = self.policy.get_actions(share_obs_input,
                                                              obs_input,
                                                              rnn_states_input,
                                                              rnn_states_critic_inputs,
                                                              masks_inputs)
                        probs = self.policy.get_probs(obs_input, rnn_states_input, masks_inputs)
                        old_q.append(value.detach().cpu().numpy())
                        old_pi.append(probs.detach().cpu().numpy())
                    old_q = np.array(old_q)
                    old_pi = np.array(old_pi)
                    old_baseline = np.sum(old_q * old_pi,axis = -1,keepdims= True)
                    old_A = old_q - old_baseline

                else:
                    old_pi = buffer.old_probs_all[:-1]

                    # (39,1,3,5) (episode_length,rollout_thread,agents, actions)
                    old_pi = old_pi.reshape(-1, self.args.n_actions)
                    old_q = buffer.old_values_all[:-1]
                    # print('old_q_shape = {}'.format(old_q.shape))
                    old_q = old_q.reshape(-1, self.args.n_actions)
                    old_baseline = buffer.baseline[:-1]
                    old_baseline = old_baseline.reshape(-1, 1)
                    old_A = old_q - old_baseline
            elif self.args.sp_clip:
                old_pi = buffer.sp_prob_all[:-1]

                # (39,1,3,5) (episode_length,rollout_thread,agents, actions)
                old_pi = old_pi.reshape(-1, self.args.sp_num)
                old_q = buffer.sp_value_all[:-1]
                # print('old_q_shape = {}'.format(old_q.shape))
                old_q = old_q.reshape(-1, self.args.sp_num)
                old_baseline = np.mean(old_q,axis=-1,keepdims=True)
                old_A = old_q - old_baseline

            print('all_state_clip = {}'.format(self.args.all_state_clip))
            print('old_pi_shape = {}'.format(old_pi.shape))
            print('buffer.obs = {}'.format(buffer.obs.shape))
            # (40,10,3,30) (epsiode_limit + 1, rollout_num,agents, state_dim)
            if self.args.true_rho_s:
                sample_state = buffer.obs[:-1,:,0,:] #(39,10,30)
                sample_state = np.mean(sample_state,axis = 1)
                # print('state_cnt = {}'.format(sample_state))
                episode_length = sample_state.shape[0]
                gamma_list = np.ones([episode_length,1])
                for i in range(1,episode_length):
                    gamma_list[i] = self.args.gamma * gamma_list[i - 1]
                rho_s = np.sum(gamma_list * sample_state,axis = 0)
                print('rho_s = {}'.format(rho_s))
            else:
                rho_s = None
            if self.args.dcmode == 1:
                if self.args.delta_decay:
                    decay_constant = (1 - (2*self.curr_delta_update)/self.all_updates )*self.clip_constant
                    print('self.min_clip_constant = {}, decay_constant = {}'.format(self.min_clip_constant,decay_constant))
                    self.curr_constant = np.maximum(self.min_clip_constant,  decay_constant)
                else:
                    self.curr_constant = self.clip_constant

                if self.args.delta_reset:
                    idv_delta = self.curr_constant / self.args.n_agents
                    idv_eps = np.exp(idv_delta) - 1
                    self.clip_param = np.ones(self.args.n_agents) * idv_eps
                print('clip update {}/{} init clip params = {}'.format(self.curr_delta_update,self.all_updates,self.clip_param))

                all_deltas = []
                for i in range(self.args.clip_update_num):
                    clip_iter, clip_solve_loss = self.update_policy_clip_ver_1(old_pi, old_A)
                    print('clip step {}: clip_params = {}'.format(i,self.clip_param))
                    all_deltas.append(self.clip_delta)
                all_deltas = np.array(all_deltas)
                final_delta = np.mean(all_deltas,axis = 0)
                final_eps = np.exp(final_delta) - 1
                self.clip_param = final_eps
                self.curr_delta_update += 1

            elif self.args.dcmode == 2:
                clip_iter, clip_solve_loss = self.update_policy_clip_ver_2(old_pi, old_A,rho_s)


            print('solved_clip_params = {}'.format( self.clip_param))
            if self.args.weighted_clip and time_steps is not None:
                ratios = np.minimum(float(time_steps)/float(self.args.weighted_clip_step),1.0)
                self.clip_param = ratios * self.clip_param + (1.0 - ratios) * self.args.weighted_clip_init
                print('weighted_clip_params = {}, time_steps = {} ratios = {}'.format(self.clip_param,time_steps,ratios))

        if self.args.penalty_method and self.args.env_name == 'mujoco' and self.args.correct_kl:
            self.policy.hard_update_policy()


        if self.args.use_q:
            if self._use_popart:
                advantages = self.value_normalizer.denormalize(buffer.value_curr[:-1]) - self.value_normalizer.denormalize(buffer.baseline[:-1])
            else:
                advantages = buffer.value_curr[:-1] - buffer.baseline[:-1]
        else:
            if self._use_popart:
                advantages = buffer.returns[:-1] - self.value_normalizer.denormalize(buffer.value_preds[:-1])
            else:
                advantages = buffer.returns[:-1] - buffer.value_preds[:-1]
        advantages_copy = advantages.copy()
        advantages_copy[buffer.active_masks[:-1] == 0.0] = np.nan
        mean_advantages = np.nanmean(advantages_copy)
        std_advantages = np.nanstd(advantages_copy)
        advantages = (advantages - mean_advantages) / (std_advantages + 1e-5)
        

        train_info = {}

        train_info['value_loss'] = 0
        train_info['policy_loss'] = 0
        train_info['dist_entropy'] = 0
        train_info['actor_grad_norm'] = 0
        train_info['critic_grad_norm'] = 0
        train_info['ratio'] = 0
        train_info['clip_rate'] = 0

        epoch_num = 0
        if self.args.new_period and buffer.aga_update_tag and self.args.aga_tag:
            epoch_num = self.ppo_epoch * self.args.period
        else:
            epoch_num = self.ppo_epoch
        if self.args.optim_reset and self.args.aga_tag and buffer.aga_update_tag:
            self.policy.optim_reset(buffer.update_index)
        curr_update_num = 0
        for epoch_cnt in range(epoch_num):
            self.es_tag = False
            self.es_kl = []
            if self._use_recurrent_policy:
                data_generator = buffer.recurrent_generator(advantages, self.num_mini_batch, self.data_chunk_length)
            elif self._use_naive_recurrent:
                data_generator = buffer.naive_recurrent_generator(advantages, self.num_mini_batch)
            else:
                data_generator = buffer.feed_forward_generator(advantages, self.num_mini_batch)

            for sample in data_generator:

                value_loss, critic_grad_norm, policy_loss, dist_entropy, actor_grad_norm, imp_weights,clip_rate \
                    = self.ppo_update(sample, update_actor,aga_update_tag = buffer.aga_update_tag,update_index = buffer.update_index,curr_update_num = epoch_cnt)

                train_info['value_loss'] += value_loss.item()
                train_info['policy_loss'] += policy_loss.item()
                train_info['dist_entropy'] += dist_entropy.item()
                train_info['actor_grad_norm'] += actor_grad_norm
                train_info['critic_grad_norm'] += critic_grad_norm
                train_info['ratio'] += imp_weights.mean()
                train_info['clip_rate'] += clip_rate
                curr_update_num += 1
                if self.args.early_stop:
                    self.es_kl = torch.mean(torch.tensor(self.es_kl))
                    self.es_tag = self.es_kl > self.args.es_judge
                    if self.es_tag:
                        print('es_kl = {}, es_judge = {}'.format(self.es_kl,self.args.es_judge))
                        print('early stop after {} epoch, total updates {}'.format(epoch_cnt,curr_update_num))
                        train_info['early_stop_epoch'] = curr_update_num
                        train_info['early_stop_kl'] = self.es_kl
                        break
            if self.es_tag:
                break
        if not self.es_tag and self.args.early_stop:
            train_info['early_stop_epoch'] = curr_update_num
            train_info['early_stop_kl'] = self.es_kl

        if self.args.target_dec:
            if self.args.soft_target:
                self.policy.soft_update_policy()
            else:
                if buffer.aga_update_tag and self.args.aga_tag:
                    self.policy.hard_update_policy()

        if self.args.sp_use_q:
            if self.args.sp_update_policy == 'hard':
                self.policy.hard_update_policy()
            else:
                self.policy.soft_update_policy()

        if self.args.use_q or self.args.sp_use_q:
            self.policy.soft_update_critic()


        num_updates = self.ppo_epoch * self.num_mini_batch

        for k in train_info.keys():
            if k in ['early_stop_epoch','early_stop_kl']:
                continue
            train_info[k] /= num_updates
        out_info_key = [ 'min_clip', 'max_clip', 'mean_clip', 'clip_rate']
        if self.args.dynamic_clip_tag and self.args.use_q:
            train_info['clip_iteration'] = clip_iter
            train_info['clip_solve_loss'] = clip_solve_loss
            out_info_key.append( 'clip_iteration')
            out_info_key.append('clip_solve_loss')

        train_info['min_clip'] = np.min(self.clip_param)
        train_info['max_clip'] = np.max(self.clip_param)
        train_info['mean_clip'] = np.mean(self.clip_param)
        out_info = ''
        for key in out_info_key:
            out_info += '{}: {}    '.format(key, train_info[key])
        print(out_info)


        return train_info

    def prep_training(self):
        if self.args.idv_para:
            for i in range(self.args.n_agents):
                self.policy.actor[i].train()
                self.policy.critic[i].train()
        else:
            self.policy.actor.train()
            self.policy.critic.train()

    def prep_rollout(self):
        if self.args.idv_para:
            for i in range(self.args.n_agents):
                self.policy.actor[i].eval()
                self.policy.critic[i].eval()
        else:
            self.policy.actor.eval()
            self.policy.critic.eval()
